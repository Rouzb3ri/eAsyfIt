import 'package:flutter/material.dart';
// import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:foodapp/Screens/dietPlanPage.dart';
import 'package:uuid/uuid.dart';

class ChatBotPage extends StatefulWidget {
  const ChatBotPage({Key? key}) : super(key: key);

  @override
  _ChatBotPageState createState() => _ChatBotPageState();
}

class _ChatBotPageState extends State<ChatBotPage> {
  TextEditingController _messageController = TextEditingController();
  // Add your chat-related variables here
  List<types.Message> _messages = [];
  final types.User _user =
      const types.User(id: '82091008-a484-4a89-ae75-a22bf8d6f3ac');
  final types.User _otherUser = const types.User(
      id: 'other_user_id',
      firstName: 'John',
      lastName: 'Doe',
      imageUrl: 'assets/profile_image.jpg');

  @override
  void initState() {
    super.initState();

    final List<String> userMessages = [
      'What are the key components of a healthy, balanced diet?',
      'How can I determine the right portion sizes for my meals?',
      'What are some healthy snacks to incorporate into my daily routine?',
      'Are there specific foods that can boost my metabolism?',
      'What are some tips for mindful eating and preventing overeating?',
      'Could you please update my diet plan?',
    ];

    final List<String> otherUserMessages = [
      'How can I help you!',
      'A balanced diet includes fruits, vegetables,\nwhole grains, lean proteins, and healthy fats.',
      'Use visual cues like your hand size and pay\nattention to hunger and fullness signals.',
      'Fresh fruits, veggies with hummus, yogurt with\nberries, or a handful of nuts make nutritious snacks.',
      'Protein-rich foods, staying hydrated, and regular\nphysical activity contribute to a healthy metabolism.',
      'Chew food slowly, savor each bite, and pay attention\nto hunger and fullness cues.',
      'You can see new diet plan '
    ];

    // Ensure the first message is from the other user
    if (otherUserMessages.isNotEmpty) {
      final types.Message firstOtherUserMessage = types.TextMessage(
        author: _otherUser,
        createdAt: DateTime.now().millisecondsSinceEpoch,
        id: const Uuid().v4(),
        text: otherUserMessages.first,
      );
      _messages.add(firstOtherUserMessage);
      otherUserMessages.removeAt(0);
    }

    // Add messages in an alternating pattern
    for (int i = 0;
        i < userMessages.length || i < otherUserMessages.length;
        i++) {
      if (i < userMessages.length) {
        final types.Message userMessage = types.TextMessage(
          author: _user,
          createdAt: DateTime.now().millisecondsSinceEpoch - i * 1000,
          id: const Uuid().v4(),
          text: userMessages[i],
        );
        _messages.insert(0, userMessage);
      }

      if (i < otherUserMessages.length) {
        final types.Message otherUserMessage = types.TextMessage(
          author: _otherUser,
          createdAt: DateTime.now().millisecondsSinceEpoch - i * 1000,
          id: const Uuid().v4(),
          text: otherUserMessages[i],
        );
        _messages.insert(0, otherUserMessage);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // appbar
            Padding(
              padding: const EdgeInsets.only(top: 16, left: 20, right: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SvgPicture.asset(
                        'assets/profile.svg',
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 32),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'eAsy fIt',
                              style: TextStyle(
                                color: Color(0x7F40B518),
                                fontSize: 24,
                                fontFamily: 'Syncopate',
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          color: const Color.fromRGBO(65, 181, 24, 1),
                          borderRadius: BorderRadius.circular(50),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: SvgPicture.asset(
                            'assets/calenderIcon.svg',
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(
              height: 20,
            ),

            // Chat UI
            Expanded(
              child: ListView.builder(
                reverse: true,
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final message = _messages[index];
                  return _messageBuilder(message);
                },
              ),
            ),

            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.only(left: 10, right: 10),
                      decoration: BoxDecoration(
                          color: const Color.fromRGBO(239, 241, 237, 1),
                          borderRadius: BorderRadius.circular(30)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: TextField(
                          controller: _messageController,
                          decoration: InputDecoration(
                            hintText: 'Messages...',
                            border: InputBorder.none,
                            suffixIcon: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(50),
                                color: const Color.fromRGBO(65, 181, 24, 1),
                              ),
                              child: const Padding(
                                padding: EdgeInsets.all(10),
                                child: Icon(
                                  Icons.mic_outlined,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          style: const TextStyle(
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  InkWell(
                    onTap: () {
                      // Call the correct function
                      if (_messageController.text != '')
                        _handleSendPressed(_messageController.text);
                      _messageController.clear();
                    },
                    child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                          color: Color.fromARGB(255, 58, 161, 21),
                        ),
                        child: const Padding(
                          padding: EdgeInsets.all(12),
                          child: Icon(
                            Icons.send,
                            color: Colors.white,
                          ),
                        )),
                  ),
                ],
              ),
            ),

            // SizedBox(
            //   height: 100,
            // ),

            // Container(
            //   margin: const EdgeInsets.only(right: 10, left: 10),
            //   padding: const EdgeInsets.only(left: 10, right: 10),
            //   decoration: BoxDecoration(
            //       color: const Color.fromRGBO(239, 241, 237, 1),
            //       borderRadius: BorderRadius.circular(30)),
            //   child: TextField(
            //     controller: _messageController,
            //     decoration: InputDecoration(
            //       hintText: 'Messages...',
            //       border: InputBorder.none,
            //       suffixIcon: Padding(
            //         padding: const EdgeInsets.all(4),
            //         child: Container(
            //           decoration: BoxDecoration(
            //             borderRadius: BorderRadius.circular(50),
            //             color: const Color.fromRGBO(65, 181, 24, 1),
            //           ),
            //           child: const Icon(
            //             Icons.mic_outlined,
            //             color: Colors.white,
            //             size: 28,
            //           ),
            //         ),
            //       ),
            //     ),
            //     style: const TextStyle(
            //       color: Colors.black,
            //     ),
            //   ),
            // ),

            const SizedBox(
              height: 100,
            )
          ],
        ),
      ),
    );
  }

  Widget _messageBuilder(types.Message message) {
    // Customize the appearance of each message here
    if (message.author.id == _otherUser.id) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(60),
                color: Color.fromRGBO(239, 241, 237, 1),
              ),
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: SvgPicture.asset(
                  "assets/chatBotIcon.svg",
                  width: 30,
                  height: 30,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_otherUser.firstName != null)
                    Container(
                      decoration: BoxDecoration(
                        color: const Color.fromRGBO(217, 217, 217, 1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 14),
                        child: Column(
                          children: [
                            Text(
                              message is types.TextMessage
                                  ? message.text
                                  : 'Unsupported message type',
                              style: const TextStyle(
                                color: Colors.black,
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                              ),
                              maxLines: null,
                            ),
                            if (message is types.TextMessage
                                ? (message as types.TextMessage).text ==
                                    'You can see new diet plan '
                                : false)
                              Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => DietPlanPage(),
                                        ));
                                  },
                                  child: Container(
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius:
                                              BorderRadius.circular(35)),
                                      child: const Padding(
                                        padding: EdgeInsets.all(6),
                                        child: Text(
                                          'HERE',
                                          style: TextStyle(
                                              color: Color.fromRGBO(
                                                  65, 181, 24, 1)),
                                        ),
                                      )),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      );
    } else if (message.author.id == _user.id) {
      // Corrected the condition to check for the user's messages
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (_user.firstName != null)
                    Container(
                      // width: 260,
                      decoration: BoxDecoration(
                        color: const Color.fromRGBO(65, 181, 24, 1),
                        borderRadius:
                            BorderRadius.circular(20), // Adjust the radius
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 14),
                        child: Text(
                          message is types.TextMessage
                              ? message.text
                              : 'Unsupported message type',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Stack(
                    children: [
                      Container(
                        // width: 300,
                        decoration: BoxDecoration(
                          color: const Color.fromRGBO(
                              65, 181, 24, 1), // Change the color as needed
                          borderRadius:
                              BorderRadius.circular(20), // Adjust the radius
                        ),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 14),
                          child: Text(
                            message is types.TextMessage
                                ? message.text
                                : 'Unsupported message type',
                            style: const TextStyle(
                              color: Colors.white,
                              fontFamily: 'Roboto',
                              fontWeight: FontWeight.w400,
                              height: 0,
                            ),
                          ),
                        ),
                      ),
                      Positioned(
                        right: 0,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 40),
                          child: SvgPicture.asset(
                            'assets/threeangle.svg',
                            width: 30,
                            height: 30,
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    } else {
      // Default appearance for other cases
      return const SizedBox();
    }
  }

  // Add your chat-related functions here

  void _handleSendPressed(String text) {
    final types.TextMessage textMessage = types.TextMessage(
      author: _user,
      createdAt: DateTime.now().millisecondsSinceEpoch,
      id: const Uuid().v4(),
      text: text,
    );

    _addMessage(textMessage);
  }

  void _addMessage(types.Message message) {
    setState(() {
      _messages.insert(0, message);
    });
  }
}
