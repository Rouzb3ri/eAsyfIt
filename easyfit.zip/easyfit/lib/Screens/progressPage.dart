import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Widgets/appbarWidget.dart';
import 'package:foodapp/Widgets/linerproccess.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class ProgressPage extends StatefulWidget {
  const ProgressPage({super.key});

  @override
  State<ProgressPage> createState() => _ProgressPageState();
}

class _ProgressPageState extends State<ProgressPage> {
  double height = 0;
  double width = 0;
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
          child: ListView(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //app bar widget
              AppBarWidget(),
              const SizedBox(
                height: 46,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20, right: 20),
                child: Column(
                  children: [
                    //goad progress bar cadr
                    Container(
                      width: width / 1.1,
                      height: height / 8.9,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: ShapeDecoration(
                        color: const Color(0xFF123321),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            margin: const EdgeInsets.only(right: 12),
                            child: CircularPercentIndicator(
                              backgroundColor: Colors.white,
                              radius: 30.0,
                              lineWidth: 5.0,
                              percent: 0.80,
                              progressColor:
                                  const Color.fromRGBO(65, 181, 24, 1),
                            ),
                          ),
                          const Text.rich(
                            TextSpan(
                              children: [
                                TextSpan(
                                  text: 'You’re going to reach your goal by\n',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.w400,
                                  ),
                                ),
                                TextSpan(
                                  text: '19 May 2024',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w700,
                                      height: 1.5),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(left: 10),
                            child: const Icon(
                              Icons.edit,
                              color: Color.fromRGBO(65, 181, 24, 1),
                            ),
                          )
                        ],
                      ),
                    ),

                    const SizedBox(
                      height: 40,
                    ),

                    //Weight progress TExt

                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Weight progress',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.w400,
                          height: 0.05,
                          letterSpacing: 2,
                        ),
                      ),
                    ),

                    const SizedBox(
                      height: 25,
                    ),

                    //Weight progress Card
                    Container(
                      alignment: Alignment.center,
                      width: width,
                      height: 191,
                      decoration: ShapeDecoration(
                        color: Color.fromRGBO(65, 181, 24, 0.3),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(35),
                        ),
                        shadows: const [
                          BoxShadow(
                            color: Color(0x3F000000),
                            offset: Offset(
                              0,
                              4,
                            ),
                            blurRadius: 10.0,
                            spreadRadius: 0,
                          ),
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ],
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SvgPicture.asset('assets/curvedLine.svg'),
                          const Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 35, vertical: 10),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  '24 Feb 2023',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.w400,
                                    height: 0.14,
                                    letterSpacing: 1.20,
                                  ),
                                ),
                                Text(
                                  'Today',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.w400,
                                    height: 0.14,
                                    letterSpacing: 1.20,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),

                    //unit percentages
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      width: width,
                      height: 120,
                      decoration: const ShapeDecoration(
                        color: Color(0xFFEFF1ED),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(35),
                            topRight: Radius.circular(35),
                          ),
                        ),
                        shadows: [
                          BoxShadow(
                            color: Color(0x3F000000),
                            blurRadius: 4,
                            offset: Offset(0, 4),
                            spreadRadius: 0,
                          )
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          LinerProccess(
                            '72',
                            'Goal weight',
                            0.70,
                            '4w left',
                            'kg',
                            30,
                            20,
                            15,
                            FontWeight.w500,
                            10,
                            const Color.fromRGBO(175, 8, 8, 1),
                            const Color.fromRGBO(175, 8, 8, 0.2),
                            5,
                          ),
                          LinerProccess(
                            '65',
                            'Current weight',
                            0.75,
                            '75%',
                            'kg',
                            30,
                            20,
                            15,
                            FontWeight.w500,
                            10,
                            const Color.fromRGBO(65, 181, 24, 1),
                            const Color.fromRGBO(65, 181, 24, 0.2),
                            5,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(
                      height: 45,
                    ),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Body Mass Index',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.w400,
                          height: 0.05,
                        ),
                      ),
                    ),

                    //BMI score Card
                    Container(
                        margin: const EdgeInsets.only(top: 15),
                        padding: const EdgeInsets.all(16),
                        width: width,
                        height: 138,
                        decoration: ShapeDecoration(
                          color: const Color(0xFFEFF1ED),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(35),
                          ),
                        ),
                        child: Column(
                          children: [
                            Container(
                              alignment: Alignment.topLeft,
                              child: Row(
                                children: [
                                  Container(
                                      margin: const EdgeInsets.only(right: 8),
                                      child: SvgPicture.asset(
                                          'assets/judgeIcon.svg')),
                                  const Text(
                                    'BMI score',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 20,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                                margin:
                                    const EdgeInsets.only(top: 20, bottom: 5),
                                child: Column(
                                  children: [
                                    Container(
                                        margin:
                                            const EdgeInsets.only(right: 180),
                                        child: const Icon(
                                          Icons.arrow_drop_down,
                                          size: 26,
                                        )),
                                    SvgPicture.asset('assets/colorsLine.svg'),
                                  ],
                                )),
                            const Text(
                              '15        18                        25              30                    35           40  ',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 12,
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                              ),
                            )
                          ],
                        )),
                    const SizedBox(
                      height: 130,
                    ),
                  ],
                ),
              )
            ],
          )
        ],
      )),
    );
  }
}
