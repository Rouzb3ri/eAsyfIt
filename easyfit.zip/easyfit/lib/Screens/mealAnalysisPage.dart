import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Screens/loadingPage.dart';
import 'package:foodapp/Widgets/bottomnav.dart';

class MealAnalysisPage extends StatefulWidget {
  const MealAnalysisPage({super.key});

  @override
  State<MealAnalysisPage> createState() => _MealAnalysisPageState();
}

class _MealAnalysisPageState extends State<MealAnalysisPage> {
  double height = 0;
  double width = 0;
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
        backgroundColor: Colors.grey.shade400,
        body: SafeArea(
          child: ListView(children: [
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  //appbar
                  Padding(
                    padding: const EdgeInsets.only(top: 16),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            InkResponse(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          BottomNav(currentIndex: 0),
                                    ));
                              },
                              splashColor: Colors.grey,
                              highlightColor: Colors.transparent,
                              borderRadius: BorderRadius.circular(50),
                              child: Container(
                                  decoration: BoxDecoration(
                                      color: const Color.fromRGBO(
                                          217, 217, 217, 1),
                                      borderRadius: BorderRadius.circular(50)),
                                  child: const Padding(
                                    padding: EdgeInsets.all(8),
                                    child: Icon(
                                      Icons.arrow_back_ios_new_rounded,
                                      size: 28,
                                    ),
                                  )),
                            ),
                            Container(
                              margin: const EdgeInsets.only(top: 32),
                              child: const Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Scan Meal',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 20,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 0,
                                      letterSpacing: 3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // width: 45,
                              // height: 45,
                              decoration: BoxDecoration(
                                  color: const Color.fromRGBO(65, 181, 24, 1),
                                  borderRadius: BorderRadius.circular(50)),
                              child: Padding(
                                padding: const EdgeInsets.all(4),
                                child: Image.asset(
                                  'assets/flash.png',
                                  width: 30,
                                  height: 30,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 80,
                  ),
                  Stack(
                    children: [
                      Container(
                        margin: const EdgeInsets.only(right: 40, left: 40),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(45)),
                        height: height / 1.6,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Padding(
                              padding: EdgeInsets.only(top: height / 3),
                              child: Container(
                                height: height / 2,
                                decoration: BoxDecoration(
                                    color: Colors.green.withOpacity(0.3),
                                    borderRadius: const BorderRadius.only(
                                      bottomLeft: Radius.circular(45),
                                      bottomRight: Radius.circular(45),
                                    )),
                              ),
                            ),
                            Image.asset(
                              'assets/burger.png',
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 40),
                        child: SvgPicture.asset(
                          'assets/curvedLine0.svg',
                        ),
                      ),
                      Positioned(
                        right: 0,
                        child: Padding(
                          padding: const EdgeInsets.only(right: 40),
                          child: SvgPicture.asset(
                            'assets/curvedLine1.svg',
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        child: Padding(
                          padding: const EdgeInsets.only(left: 40),
                          child: SvgPicture.asset(
                            'assets/curvedLine2.svg',
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: Padding(
                          padding: const EdgeInsets.only(right: 40),
                          child: SvgPicture.asset(
                            'assets/curvedLine3.svg',
                          ),
                        ),
                      ),
                    ],
                  ),
                  // QRCodeReaderTransparentWidget(
                  //   onDetect: (QRCodeCapture capture) =>
                  //       setState(() => list.add(capture)),
                  //   targetSize: 100,
                  // ),
                  // Expanded(
                  //   child: ListView.builder(
                  //     itemCount: list.length,
                  //     itemBuilder: (_, index) {
                  //       return ListTile(title: Text(list[index].raw));
                  //     },
                  //   ),
                  // ),
                  const SizedBox(
                    height: 50,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 98,
                        height: 42,
                        child: TextButton(
                            style: ButtonStyle(
                              shape: MaterialStateProperty.all<OutlinedBorder>(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(
                                      35), // Adjust the radius as needed
                                ),
                              ),
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Colors.white),
                            ),
                            onPressed: () {
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => LoadingPage(),
                                ),
                              );
                            },
                            child: const Text(
                              'Upload',
                              style: TextStyle(
                                color: Color(0xFF123321),
                                fontSize: 20,
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                height: 0,
                                letterSpacing: 3,
                              ),
                            )),
                      ),
                      const SizedBox(
                        width: 112,
                      ),
                      Container(
                        width: 98,
                        height: 42,
                        child: TextButton(
                            style: ButtonStyle(
                              shape: MaterialStateProperty.all<OutlinedBorder>(
                                RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(
                                      35), // Adjust the radius as needed
                                ),
                              ),
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Colors.white),
                            ),
                            onPressed: () {},
                            child: const Text(
                              'Retake',
                              style: TextStyle(
                                color: Color(0xFF123321),
                                fontSize: 20,
                                fontFamily: 'Roboto',
                                fontWeight: FontWeight.w400,
                                height: 0,
                                letterSpacing: 3,
                              ),
                            )),
                      ),
                    ],
                  ),

                  const SizedBox(
                    height: 130,
                  ),
                ],
              ),
            )
          ]),
        ));
  }
}
