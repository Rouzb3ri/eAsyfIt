import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Widgets/appbarWidget.dart';
import 'package:foodapp/Widgets/bottomnav.dart';

class DietPlanPage extends StatefulWidget {
  @override
  _DietPlanPageState createState() => _DietPlanPageState();
}

class _DietPlanPageState extends State<DietPlanPage> {
  int selectedIndex = 2;

  double height = 0;
  double width = 0;

  Color greenColor = const Color.fromRGBO(65, 181, 24, 1);

  List<String> breakFastIcons = [
    'assets/eggIcon.svg',
    'assets/avocadoIcon.svg',
    'assets/toastIcon.svg',
  ];
  List<String> breakFastNames = [
    'Egg',
    'Avocado',
    'Whole Grain Toast',
  ];
  List<String> breakFastAmount = [
    '2 Large',
    '1 Medium',
    'Toast, 1 slice',
  ];
  List<String> breakFastAmountCal = [
    '142',
    '240',
    '100',
  ];

  List<String> mealTitle = [
    'Lunch',
    'Dinner',
    'Snacks',
    'Exercise',
    'Water',
  ];
  List<String> mealText = [
    'Recommended 535 - 731 Kcal',
    'Recommended 535 - 731 Kcal',
    'Recommended 89 - 178 Kcal',
    'Recommended 30 mins',
    'Recommended 5Ltrs.',
  ];
  List<String> mealIconPath = [
    'assets/meal1.svg',
    'assets/meal2.svg',
    'assets/meal3.svg',
    'assets/exerciseIcon.svg',
    'assets/waterIcon.svg',
  ];

  List<String> bottomIcons = [
    'assets/homeIcon.svg',
    'assets/searchIcon.svg',
    'assets/dietIcon.svg',
    'assets/botIcon.svg'
  ];

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      // bottomNavigationBar: BottomNav(),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            ListView(children: [
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
                //appbar
                Padding(
                  padding: const EdgeInsets.only(bottom: 50),
                  child: AppBarWidget(),
                ),

                Column(children: [
                  //breakfast Cadr
                  Container(
                    padding: const EdgeInsets.all(14),
                    width: width / 1.13,
                    height: 300,
                    decoration: ShapeDecoration(
                      color: const Color(0xFFEFF1ED),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(35),
                      ),
                      shadows: const [
                        BoxShadow(
                          color: Color(0x3F000000),
                          blurRadius: 4,
                          offset: Offset(0, 4),
                          spreadRadius: 0,
                        )
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SvgPicture.asset(
                              'assets/meal0.svg',
                              width: 35,
                              height: 28,
                            ),
                            const Text(
                              'Breakfast',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16,
                                fontFamily: 'SF Compact Display',
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            Icon(
                              Icons.remove_circle,
                              color: greenColor,
                              size: 32,
                            ),
                          ],
                        ),
                        const Text(
                          'Recommended 356 - 535 Kcal',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 11,
                            fontFamily: 'SF Compact Display',
                            fontWeight: FontWeight.w300,
                            height: 0,
                          ),
                        ),
                        Container(
                          alignment: Alignment.center,
                          margin: const EdgeInsets.only(top: 8, bottom: 20),
                          width: width / 1.8,
                          height: 32,
                          decoration: ShapeDecoration(
                            color: const Color(0x4C40B518),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            shadows: const [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              ),
                              BoxShadow(
                                color: Colors.white,
                                offset: Offset(0.0, 0.0),
                                blurRadius: 0.0,
                                spreadRadius: 0.0,
                              ),
                            ],
                          ),
                          child: const Text(
                            'Net carbs 16% Fat 66% Protein 23%',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 10,
                              fontFamily: 'Roboto',
                              fontWeight: FontWeight.w400,
                              letterSpacing: 1.50,
                            ),
                          ),
                        ),
                        Expanded(
                          child: ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: 2,
                            itemBuilder: (context, index) {
                              return Center(
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 12),
                                  width: width / 1.8,
                                  child: (Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.only(
                                                right: 10),
                                            child: SvgPicture.asset(
                                                breakFastIcons[index]),
                                          ),
                                          Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                breakFastNames[index],
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 11,
                                                  fontFamily:
                                                      'SF Compact Display',
                                                  fontWeight: FontWeight.w300,
                                                ),
                                              ),
                                              const SizedBox(
                                                height: 6,
                                              ),
                                              Text(
                                                breakFastAmount[index],
                                                textAlign: TextAlign.center,
                                                style: const TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 11,
                                                  fontFamily:
                                                      'SF Compact Display',
                                                  fontWeight: FontWeight.w300,
                                                ),
                                              )
                                            ],
                                          )
                                        ],
                                      ),
                                      Text(
                                        breakFastAmountCal[index],
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 11,
                                          fontFamily: 'SF Compact Display',
                                          fontWeight: FontWeight.w300,
                                        ),
                                      ),
                                    ],
                                  )),
                                ),
                              );
                            },
                          ),
                        ),
                        Center(
                          child: Container(
                            margin: const EdgeInsets.only(bottom: 6, left: 46),
                            width: width / 1.3,
                            child: (Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(right: 10),
                                      child:
                                          SvgPicture.asset(breakFastIcons[2]),
                                    ),
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          breakFastNames[2],
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            color: Colors.black,
                                            fontSize: 11,
                                            fontFamily: 'SF Compact Display',
                                            fontWeight: FontWeight.w300,
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 8,
                                        ),
                                        Text(
                                          breakFastAmount[2],
                                          textAlign: TextAlign.center,
                                          style: const TextStyle(
                                            color: Colors.black,
                                            fontSize: 11,
                                            fontFamily: 'SF Compact Display',
                                            fontWeight: FontWeight.w300,
                                          ),
                                        )
                                      ],
                                    )
                                  ],
                                ),
                                const SizedBox(
                                  width: 58,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      breakFastAmountCal[2],
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontSize: 11,
                                        fontFamily: 'SF Compact Display',
                                        fontWeight: FontWeight.w300,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 25),
                                      child: InkResponse(
                                        onTap: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => BottomNav(
                                                  currentIndex: 3,
                                                ),
                                              ));
                                        },
                                        splashColor: Colors.grey,
                                        highlightColor: Colors.transparent,
                                        child: SvgPicture.asset(
                                          'assets/botIcon.svg',
                                          width: 28,
                                          height: 28,
                                          color: greenColor,
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ],
                            )),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                    height: 20,
                  ),

                  //meal Cadr
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: 5,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        child: Container(
                          padding: const EdgeInsets.only(left: 16, right: 16),
                          width: width / 1.13,
                          height: 75,
                          margin: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 14),
                          decoration: ShapeDecoration(
                            color: const Color(0xFFEFF1ED),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                            ),
                            shadows: const [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  SvgPicture.asset(mealIconPath[index]),
                                  const SizedBox(
                                    width: 18,
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        mealTitle[index],
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 16,
                                          fontFamily: 'SF Compact Display',
                                          fontWeight: FontWeight.w600,
                                          height: 0,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 8,
                                      ),
                                      Text(
                                        mealText[index],
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontSize: 11,
                                          fontFamily: 'SF Compact Display',
                                          fontWeight: FontWeight.w300,
                                          height: 0,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              InkResponse(
                                onTap: () {},
                                splashColor:
                                    const Color.fromRGBO(239, 241, 237, 1),
                                highlightColor: Colors.transparent,
                                borderRadius: BorderRadius.circular(50),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: const Color.fromRGBO(65, 181, 24, 1),
                                    borderRadius: BorderRadius.circular(50),
                                  ),
                                  child: const Icon(
                                    Icons.add,
                                    color: Colors.white,
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                      );
                    },
                  ),

                  const SizedBox(
                    height: 130,
                  ),
                ]),
              ]),
            ]),
            Positioned(
              bottom: 0,
              right: 0,
              left: 0,
              child: Container(
                alignment: Alignment.center,
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                // width: width,
                // height: 70,
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(35),
                  color: const Color.fromRGBO(18, 51, 33, 1),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    for (int index = 0; index < 4; index++)
                      Column(
                        children: [
                          InkWell(
                            onTap: () {
                              setState(() {
                                selectedIndex = index;
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => BottomNav(
                                          currentIndex: selectedIndex),
                                    ));
                              });
                            },
                            child: SvgPicture.asset(bottomIcons[index]),
                          ),
                          if (index == selectedIndex)
                            Container(
                              margin: const EdgeInsets.only(top: 4),
                              height: 7,
                              width: 39,
                              color: const Color(0xFF40B518),
                            ),
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
