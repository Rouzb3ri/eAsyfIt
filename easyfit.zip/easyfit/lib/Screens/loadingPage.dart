import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Screens/reportPage.dart';
import 'package:foodapp/Widgets/bottomnav.dart';

class LoadingPage extends StatefulWidget {
  const LoadingPage({super.key});

  @override
  State<LoadingPage> createState() => _LoadingPageState();
}

class _LoadingPageState extends State<LoadingPage> {
  double height = 0;
  double width = 0;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    navigateToHomeScreen(context);
  }

  void navigateToHomeScreen(BuildContext context) {
    // Add a delay before navigating to simulate progress
    Future.delayed(Duration(seconds: 4), () {
      // Navigate to the home screen
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ReportPage(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    double size = MediaQuery.of(context).size.shortestSide * 1;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            //appbar
            Stack(
              children: [
                Container(
                    margin: EdgeInsets.only(left: 80),
                    child: SvgPicture.asset(
                      'assets/treeLines.svg',
                      width: 400,
                      height: 180,
                    )),
                Padding(
                  padding: const EdgeInsets.only(top: 16, left: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          InkResponse(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        BottomNav(currentIndex: 0),
                                  ));
                            },
                            splashColor: Colors.grey,
                            highlightColor: Colors.transparent,
                            borderRadius: BorderRadius.circular(50),
                            child: Container(
                              decoration: BoxDecoration(
                                color: const Color.fromRGBO(217, 217, 217, 1),
                                borderRadius: BorderRadius.circular(50),
                              ),
                              child: const Padding(
                                padding: EdgeInsets.all(8),
                                child: Icon(
                                  Icons.arrow_back_ios_new_rounded,
                                  size: 28,
                                ),
                              ),
                            ),
                          ),
                          Container(
                            margin: const EdgeInsets.only(top: 32),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 182,
                                  height: 27,
                                  child: Text(
                                    'eAsy fIt',
                                    style: TextStyle(
                                      color: Color(0x7F40B518),
                                      fontSize: 24,
                                      fontFamily: 'Syncopate',
                                      fontWeight: FontWeight.w700,
                                      height: 0,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          Container(),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),

            Image.asset(
              'assets/robotPic.png',
              width: size,
              height: size,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: LinearProgressIndicator(
                  minHeight: 26,
                  borderRadius: BorderRadius.circular(35),
                  backgroundColor: Color.fromRGBO(65, 181, 24, 0.2),
                  valueColor: AlwaysStoppedAnimation<Color>(
                      Color.fromRGBO(65, 181, 24, 1)),
                  semanticsLabel:
                      'Loading', // Provide a semantics label for accessibility
                  semanticsValue: '100%'),
            ),
            const SizedBox(
              height: 15,
            ),

            Text(
              'Loading...',
              style: TextStyle(
                color: const Color(0xFF123321),
                fontSize: 20,
                fontFamily: 'Roboto',
                fontWeight: FontWeight.w700,
                height: 0,
                letterSpacing: width / 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
