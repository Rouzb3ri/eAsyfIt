import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Widgets/appbarWidget.dart';
import 'package:foodapp/Widgets/linerproccess.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Color lightGreen = Color.fromRGBO(65, 181, 24, 0.2);
  double height = 0;
  double width = 0;

  List<String> mealText = [
    'Breakfast',
    'Lunch',
    'Dinner',
    'Snack',
  ];

  int fillWater = 0;
  int emptyWater = 6;
  String addwater = 'assets/emptyglass.svg';

  double waterPer = 0;
  double waterMl = 0;
  double changePic = 7;

  void fillGlass() {
    if (emptyWater > 0) {
      setState(() {
        fillWater += 1;
        emptyWater -= 1;
        waterPer += 14.3;
        waterMl += 286;
      });
    }

    if (changePic >= 0) {
      changePic -= 1;
    }

    print('empty: $emptyWater');
    print('fill: $fillWater');

    if (changePic == 0) {
      setState(() {
        addwater = 'assets/fillglass.svg';
        waterPer = 100;
        waterMl = 2000;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      // bottomNavigationBar: BottomNav(),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              //appbar
              AppBarWidget(),

              Column(
                children: [
                  //good morning part
                  Container(
                    margin: const EdgeInsets.only(top: 24),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Text(
                          'Good Morning',
                          style: TextStyle(
                            color: Color(0xFF123321),
                            fontSize: 24,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w400,
                            height: 0,
                            letterSpacing: 4.80,
                          ),
                        ),
                        SvgPicture.asset('assets/sonIcon.svg')
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 24,
                  ),

                  //
                  const Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: 'You’ve gained ',
                          style: TextStyle(
                            color: Color(0xFF7A7A7A),
                            fontSize: 12,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w400,
                            height: 0,
                            letterSpacing: 2.40,
                          ),
                        ),
                        TextSpan(
                          text: '1kg',
                          style: TextStyle(
                            color: Color(0xFF40B518),
                            fontSize: 12,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w400,
                            height: 0,
                            letterSpacing: 2.40,
                          ),
                        ),
                        TextSpan(
                          text: ' yesterday keep it up!',
                          style: TextStyle(
                            color: Color(0xFF7A7A7A),
                            fontSize: 12,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w400,
                            height: 0,
                            letterSpacing: 2.40,
                          ),
                        ),
                      ],
                    ),
                  ),

                  //proccess bar cadr
                  Container(
                    alignment: Alignment.center,
                    margin: const EdgeInsets.only(top: 24),
                    height: height / 3.7,
                    width: width / 1.08,
                    decoration: BoxDecoration(
                        color: lightGreen,
                        borderRadius: BorderRadius.circular(35),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x3F000000),
                            offset: Offset(
                              0,
                              4,
                            ),
                            blurRadius: 10.0,
                            spreadRadius: 0,
                          ),
                          BoxShadow(
                            color: Colors.white,
                            offset: Offset(0.0, 0.0),
                            blurRadius: 0.0,
                            spreadRadius: 0.0,
                          ),
                        ]),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            SvgPicture.asset(
                              'assets/circlebar.svg',
                              width: 152,
                              height: 152,
                            ),
                            Positioned.fill(
                              child: Center(
                                  child: Padding(
                                padding: const EdgeInsets.all(14),
                                child: Column(
                                  children: [
                                    Image.asset('assets/flame.png'),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    const Text(
                                      'Calories',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Color(0xFF123321),
                                        fontSize: 12,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w500,
                                        height: 0.21,
                                        letterSpacing: 1.20,
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 32,
                                    ),
                                    const Text.rich(
                                      TextSpan(
                                        children: [
                                          TextSpan(
                                            text: '1774',
                                            style: TextStyle(
                                              color: Color(0xFF123321),
                                              fontSize: 24,
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.w500,
                                              height: 0.05,
                                              letterSpacing: 2.40,
                                            ),
                                          ),
                                          TextSpan(
                                            text: ' kcal',
                                            style: TextStyle(
                                              color: Color(0xFF123321),
                                              fontSize: 12,
                                              fontFamily: 'Roboto',
                                              fontWeight: FontWeight.w500,
                                              height: 0.21,
                                              letterSpacing: 1.20,
                                            ),
                                          ),
                                        ],
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                    const SizedBox(
                                      height: 32,
                                    ),
                                    const Text(
                                      'of 2950 kcal',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: Color(0xFF123321),
                                        fontSize: 11,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                        height: 0.25,
                                        letterSpacing: 1.10,
                                      ),
                                    ),
                                  ],
                                ),
                              )),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(
                    height: 20,
                  ),

                  //cadr with liner proccess
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    width: width / 1.08,
                    height: height / 12,
                    decoration: ShapeDecoration(
                      color: const Color(0xFFEFF1ED),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(35),
                      ),
                      shadows: const [
                        BoxShadow(
                          color: Color(0x3F000000),
                          blurRadius: 4,
                          offset: Offset(0, 4),
                          spreadRadius: 0,
                        )
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        LinerProccess(
                          '135',
                          'Total carbs',
                          0.5,
                          '50%',
                          'g',
                          15,
                          15,
                          10,
                          FontWeight.w300,
                          5,
                          const Color.fromRGBO(234, 49, 49, 1),
                          const Color.fromRGBO(243, 211, 211, 1),
                          0,
                        ),
                        LinerProccess(
                          '95',
                          'Total fat',
                          0.83,
                          '83%',
                          'g',
                          15,
                          15,
                          10,
                          FontWeight.w300,
                          5,
                          const Color.fromRGBO(234, 49, 49, 1),
                          const Color.fromRGBO(243, 211, 211, 1),
                          0,
                        ),
                      ],
                    ),
                  ),

                  Container(
                    alignment: Alignment.centerLeft,
                    margin: const EdgeInsets.only(left: 20, top: 34),
                    child: const Text(
                      'Diet summary',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFF123321),
                        fontSize: 20,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 0.07,
                        letterSpacing: 2,
                      ),
                    ),
                  ),

                  //meal cadrs
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: 4,
                    itemBuilder: (context, index) {
                      return Container(
                        padding: const EdgeInsets.only(left: 16, right: 16),
                        width: 364.97,
                        height: 56,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 14),
                        decoration: ShapeDecoration(
                          color: const Color(0xFFEFF1ED),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(35),
                          ),
                          shadows: const [
                            BoxShadow(
                              color: Color(0x3F000000),
                              blurRadius: 4,
                              offset: Offset(0, 4),
                              spreadRadius: 0,
                            )
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                SvgPicture.asset('assets/meal${index}.svg'),
                                const SizedBox(
                                  width: 18,
                                ),
                                Text(
                                  '${mealText[index]}',
                                  style: const TextStyle(
                                    color: Color(0xFF123321),
                                    fontSize: 20,
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.w400,
                                    height: 0,
                                  ),
                                ),
                              ],
                            ),
                            InkResponse(
                              onTap: () {
                                Navigator.pushNamed(
                                  context,
                                  '/mealPage',
                                  arguments: index,
                                );
                              },
                              splashColor:
                                  const Color.fromRGBO(239, 241, 237, 1),
                              highlightColor: Colors.transparent,
                              borderRadius: BorderRadius.circular(50),
                              child: Container(
                                decoration: BoxDecoration(
                                  color: const Color.fromRGBO(65, 181, 24, 1),
                                  borderRadius: BorderRadius.circular(50),
                                ),
                                child: const Icon(
                                  Icons.add,
                                  color: Colors.white,
                                ),
                              ),
                            )
                          ],
                        ),
                      );
                    },
                  ),
                  SizedBox(
                    height: height / 30,
                  ),

                  //water text part
                  Container(
                    margin:
                        const EdgeInsets.only(left: 20, right: 20, bottom: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Water',
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontFamily: 'Roboto',
                            fontWeight: FontWeight.w400,
                            height: 0,
                          ),
                        ),
                        Container(
                          alignment: Alignment.center,
                          padding: const EdgeInsets.symmetric(horizontal: 10),
                          width: 41,
                          height: 18,
                          decoration: ShapeDecoration(
                            color: const Color(0xFF123321),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: List.generate(
                              3,
                              (index) => Container(
                                width: 3,
                                height: 3,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(40),
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),

                  //water cadr
                  Container(
                    width: width / 1.1,
                    height: 106,
                    padding: const EdgeInsets.only(left: 24),
                    decoration: ShapeDecoration(
                      color: const Color(0xFF40B518),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(35),
                      ),
                      shadows: const [
                        BoxShadow(
                          color: Color(0x3F000000),
                          blurRadius: 4,
                          offset: Offset(0, 4),
                          spreadRadius: 0,
                        )
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: height / 30,
                        ),
                        Row(
                          children: [
                            Row(
                              children: List.generate(
                                  fillWater,
                                  (index) => Container(
                                      margin: const EdgeInsets.only(right: 10),
                                      child: SvgPicture.asset(
                                          'assets/fillglass.svg'))),
                            ),
                            Stack(alignment: Alignment.center, children: [
                              Container(child: SvgPicture.asset(addwater)),
                              InkWell(
                                onTap: () {
                                  print(fillWater);
                                  print(emptyWater);
                                  if (changePic >= 0) {
                                    fillGlass();
                                  }
                                },
                                child: const Icon(
                                  Icons.add,
                                  color: Colors.white,
                                ),
                              )
                            ]),
                            Row(
                              children: List.generate(
                                  emptyWater,
                                  (index) => Container(
                                      margin: const EdgeInsets.only(left: 10),
                                      child: SvgPicture.asset(
                                          'assets/emptyglass.svg'))),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                '${waterMl.toStringAsFixed(0)} / 2000 ml',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontFamily: 'Roboto',
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              Text(
                                '${waterPer.toStringAsFixed(0)}%',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontFamily: 'Roboto',
                                  fontWeight: FontWeight.w400,
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),

                  const SizedBox(
                    height: 130,
                  ),
                ],
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
