import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Widgets/bottomnav.dart';
import 'package:foodapp/Widgets/linerproccess.dart';

class MealPage extends StatefulWidget {
  const MealPage({super.key});

  @override
  State<MealPage> createState() => _MealPageState();
}

class _MealPageState extends State<MealPage> {
  double height = 0;
  double width = 0;

  int selectedIndex = 0;

  List<String> bottomIcons = [
    'assets/homeIcon.svg',
    'assets/searchIcon.svg',
    'assets/dietIcon.svg',
    'assets/botIcon.svg'
  ];

  List<String> mealText = [
    'Breakfast',
    'Lunch',
    'Dinner',
    'Snack',
  ];

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    final int whichMealIndex =
        ModalRoute.of(context)!.settings.arguments as int;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                Expanded(
                  child: ListView(children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            //appbar
                            Padding(
                              padding: const EdgeInsets.only(top: 16),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      InkResponse(
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                        splashColor: Colors.grey,
                                        highlightColor: Colors.transparent,
                                        borderRadius: BorderRadius.circular(50),
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: const Color.fromRGBO(
                                                  217, 217, 217, 1),
                                              borderRadius:
                                                  BorderRadius.circular(50)),
                                          child: const Padding(
                                            padding: EdgeInsets.all(8),
                                            child: Icon(
                                              Icons.arrow_back_ios_new_rounded,
                                              size: 28,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        margin: const EdgeInsets.only(top: 32),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              mealText[whichMealIndex],
                                              style: const TextStyle(
                                                color: Color(0xFF123321),
                                                fontSize: 20,
                                                fontFamily: 'Roboto',
                                                fontWeight: FontWeight.w400,
                                                height: 0,
                                                letterSpacing: 3,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      InkWell(
                                        onTap: () {
                                          Navigator.pushReplacement(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    BottomNav(currentIndex: 2),
                                              ));
                                        },
                                        child: Container(
                                          // width: 45,
                                          // height: 45,
                                          decoration: BoxDecoration(
                                              color: const Color.fromRGBO(
                                                  65, 181, 24, 1),
                                              borderRadius:
                                                  BorderRadius.circular(50)),
                                          child: Padding(
                                            padding: const EdgeInsets.all(1),
                                            child: SvgPicture.asset(
                                              'assets/scanIcon.svg',
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 26,
                            ),

                            //search text field
                            Container(
                              decoration: ShapeDecoration(
                                color: const Color.fromRGBO(239, 241, 237, 1),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(35),
                                ),
                                shadows: const [
                                  BoxShadow(
                                    color: Color(0x3F000000),
                                    blurRadius: 4,
                                    offset: Offset(0, 4),
                                    spreadRadius: 0,
                                  )
                                ],
                              ),
                              child: TextField(
                                decoration: InputDecoration(
                                    hintText: 'Search food',
                                    hintStyle: const TextStyle(
                                      fontSize: 18,
                                    ),
                                    suffixIcon: IconButton(
                                      icon: const Icon(
                                        Icons.search_sharp,
                                        color: Colors.black,
                                        size: 30,
                                      ),
                                      onPressed: () {
                                        // Clear search text
                                      },
                                    ),
                                    contentPadding: const EdgeInsets.all(16),
                                    border: InputBorder.none),
                              ),
                            ),
                            const SizedBox(
                              height: 26,
                            ),

                            Container(
                              child: Image.asset('assets/lineCadr.png'),
                            ),

                            const SizedBox(
                              height: 16,
                            ),

                            //percentage Cadr
                            Container(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 10),
                              width: width / 1.08,
                              height: height / 3.4,
                              decoration: const ShapeDecoration(
                                color: Color(0xFFEFF1ED),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(35),
                                    topRight: Radius.circular(35),
                                  ),
                                ),
                                shadows: [
                                  BoxShadow(
                                    color: Color(0x3F000000),
                                    blurRadius: 4,
                                    offset: Offset(0, 4),
                                    spreadRadius: 0,
                                  )
                                ],
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      LinerProccess(
                                        '583',
                                        'Calorie gained',
                                        0.87,
                                        '87%',
                                        'kcal',
                                        30,
                                        20,
                                        15,
                                        FontWeight.w500,
                                        10,
                                        const Color.fromRGBO(175, 8, 8, 1),
                                        const Color.fromRGBO(175, 8, 8, 0.2),
                                        5,
                                      ),
                                      LinerProccess(
                                          '58',
                                          'Carbs',
                                          0.20,
                                          '20%',
                                          'g',
                                          30,
                                          20,
                                          15,
                                          FontWeight.w500,
                                          10,
                                          const Color.fromRGBO(65, 181, 24, 1),
                                          const Color.fromRGBO(
                                              65, 181, 24, 0.2),
                                          5),
                                    ],
                                  ),
                                  SizedBox(
                                    height: height / 20,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      LinerProccess(
                                        '27',
                                        'Fat',
                                        0.25,
                                        '25%',
                                        'g',
                                        30,
                                        20,
                                        15,
                                        FontWeight.w500,
                                        10,
                                        const Color.fromRGBO(255, 124, 1, 1),
                                        const Color.fromRGBO(255, 124, 1, 0.2),
                                        5,
                                      ),
                                      LinerProccess(
                                        '31',
                                        'Protein',
                                        0.47,
                                        '47%',
                                        'g',
                                        30,
                                        20,
                                        15,
                                        FontWeight.w500,
                                        10,
                                        const Color.fromRGBO(152, 57, 229, 1),
                                        const Color.fromRGBO(152, 57, 229, 0.2),
                                        5,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(
                              height: 26,
                            ),

                            Container(
                              alignment: Alignment.centerLeft,
                              child: const Text(
                                'Lunch Log',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 20,
                                  fontFamily: 'Roboto',
                                  fontWeight: FontWeight.w400,
                                  height: 0,
                                  letterSpacing: 3,
                                ),
                              ),
                            ),

                            const SizedBox(
                              height: 26,
                            ),

                            //lunch log Card
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              width: width / 1.08,
                              height: 94,
                              decoration: ShapeDecoration(
                                color: const Color(0xFFEFF1ED),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(35),
                                ),
                                shadows: const [
                                  BoxShadow(
                                    color: Color(0x3F000000),
                                    blurRadius: 4,
                                    offset: Offset(0, 4),
                                    spreadRadius: 0,
                                  )
                                ],
                              ),
                              child: Column(
                                children: [
                                  const Text(
                                    'Grilled chicken',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 12,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 0,
                                      letterSpacing: 1.80,
                                    ),
                                  ),
                                  // SizedBox(
                                  //   height: 10,
                                  // ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            width: width / 16,
                                          ),
                                          /////////////
                                          unitsAndColors('125 kcal',
                                              const Color(0xFFAF0707)),
                                          unitsAndColors(
                                              '86 g', const Color(0xFF40B518)),
                                          unitsAndColors(
                                              '10 g', const Color(0xFFFF7C03)),
                                          unitsAndColors(
                                              '35 g', const Color(0xFF9938E5)),
                                        ],
                                      ),
                                      Column(
                                        children: [
                                          SvgPicture.asset(
                                              'assets/removeIcon.svg'),
                                          const Icon(
                                            Icons.edit,
                                            color:
                                                Color.fromRGBO(65, 181, 24, 1),
                                          )
                                          // SvgPicture.asset('assets/removeIcon.svg'),
                                        ],
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(
                              height: 56,
                            ),

                            //second lunch log
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              width: width / 1.08,
                              height: 94,
                              decoration: ShapeDecoration(
                                color: const Color(0xFFEFF1ED),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(35),
                                ),
                                shadows: const [
                                  BoxShadow(
                                    color: Color(0x3F000000),
                                    blurRadius: 4,
                                    offset: Offset(0, 4),
                                    spreadRadius: 0,
                                  )
                                ],
                              ),
                              child: Column(
                                children: [
                                  const Text(
                                    'Rice',
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 12,
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.w400,
                                      height: 0,
                                      letterSpacing: 1.80,
                                    ),
                                  ),
                                  // SizedBox(
                                  //   height: 10,
                                  // ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          SizedBox(
                                            width: width / 16,
                                          ),
                                          /////////////
                                          unitsAndColors('109 kcal',
                                              const Color(0xFFAF0707)),
                                          unitsAndColors(
                                              '60 g', const Color(0xFF40B518)),
                                          unitsAndColors(
                                              '15 g', const Color(0xFFFF7C03)),
                                          unitsAndColors(
                                              '26 g', const Color(0xFF9938E5)),
                                        ],
                                      ),
                                      Column(
                                        children: [
                                          SvgPicture.asset(
                                              'assets/removeIcon.svg'),
                                          const Icon(
                                            Icons.edit,
                                            color:
                                                Color.fromRGBO(65, 181, 24, 1),
                                          )
                                          // SvgPicture.asset('assets/removeIcon.svg'),
                                        ],
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(
                              height: 147,
                            ),
                          ]),
                    ),
                  ]),
                ),
              ],
            ),
            Positioned(
              bottom: 0,
              right: 0,
              left: 0,
              child: Container(
                alignment: Alignment.center,
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(35),
                  color: const Color.fromRGBO(18, 51, 33, 1),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    for (int index = 0; index < 4; index++)
                      Column(
                        children: [
                          InkWell(
                            onTap: () {
                              setState(() {
                                selectedIndex = index;
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => BottomNav(
                                          currentIndex: selectedIndex),
                                    ));
                              });
                            },
                            child: SvgPicture.asset(bottomIcons[index]),
                          ),
                          if (index == selectedIndex)
                            Container(
                              margin: const EdgeInsets.only(top: 4),
                              height: 7,
                              width: 39,
                              color: const Color(0xFF40B518),
                            ),
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget unitsAndColors(String text, Color circleColor) {
  return (Row(
    children: [
      Container(
        margin: const EdgeInsets.only(right: 4, left: 14),
        width: 10,
        height: 10,
        decoration: ShapeDecoration(
          color: circleColor,
          shape: const OvalBorder(),
        ),
      ),
      Text(
        text,
        style: const TextStyle(
          color: Colors.black,
          fontSize: 12,
          fontFamily: 'Roboto',
          fontWeight: FontWeight.w400,
          height: 0,
          letterSpacing: 1.80,
        ),
      )
    ],
  ));
}
