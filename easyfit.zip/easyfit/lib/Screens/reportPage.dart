import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Widgets/appbarWidget.dart';
import 'package:foodapp/Widgets/bottomnav.dart';
import 'package:toast/toast.dart';

class ReportPage extends StatefulWidget {
  const ReportPage({Key? key}) : super(key: key);

  @override
  State<ReportPage> createState() => _ReportPageState();
}

class _ReportPageState extends State<ReportPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    ToastContext().init(context);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  List<String> Ingredients = [
    '4 boneless, skinless chicken breasts',
    '1/4 cup olive oil',
    '2 tablespoons soy sauce',
    '2 tablespoons lemon juice',
    '2 cloves garlic, minced',
    '1 teaspoon dried oregano',
    '1 teaspoon dried thyme',
    '1 teaspoon smoked paprika'
  ];

  List<String> nutrientsTitle = [
    'Calories',
    'Protein',
    'Total Fat',
    'Saturated Fat',
    'Monounsaturated Fat',
    'Polyunsaturated Fat',
    'Cholesterol',
    'Sodium',
    'Total Carbohydrates',
    'Dietary Fiber',
    'Sugars',
  ];

  List<String> nutrientsText = [
    'Around 165 calories',
    'Approximately 31 grams',
    'About 3.6 grams',
    'Around 1 gram',
    'About 1.5 grams',
    'Approximately 0.8 grams',
    'About 85 milligrams',
    'Around 74 milligrams',
    'Almost 0 grams',
    'Approximately 0 grams',
    'Almost 0 grams',
  ];

  List<String> bottomIcons = [
    'assets/homeIcon.svg',
    'assets/searchIcon.svg',
    'assets/dietIcon.svg',
    'assets/botIcon.svg'
  ];

  double height = 0;
  double width = 0;

  int selectedIndex = 2;

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: AppBarWidget(
                    isBack: true,
                  ),
                ),
                const SizedBox(height: 64),
                Container(
                  alignment: Alignment.centerLeft,
                  margin: const EdgeInsets.only(left: 20),
                  child: const Text(
                    'Report',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontFamily: 'Roboto',
                      fontWeight: FontWeight.w700,
                      letterSpacing: 3,
                    ),
                  ),
                ),
                const SizedBox(height: 52),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: TabBar(
                    isScrollable: true,
                    labelColor: Colors.white,
                    unselectedLabelColor: Colors.black,
                    labelStyle: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontFamily: 'Roboto',
                      fontWeight: FontWeight.w400,
                      letterSpacing: 2,
                    ),
                    controller: _tabController,
                    indicator: BoxDecoration(
                      color: const Color.fromRGBO(18, 51, 33, 1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    tabs: const [
                      Tab(text: 'Description'),
                      Tab(text: 'Ingredients'),
                      Tab(text: 'Nutrients'),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 30,
                ),
                SizedBox(
                  height: height - 370, // Adjust the height as needed
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      // Content of Tab 1
                      Center(
                        child: Container(
                          width: width / 1.1,
                          height: 390,
                          decoration: ShapeDecoration(
                            color: const Color(0xFFEFF1ED),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35),
                            ),
                            shadows: const [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                          child: const SingleChildScrollView(
                            child: Padding(
                              padding: EdgeInsets.all(20),
                              child: Text.rich(
                                TextSpan(
                                  children: [
                                    TextSpan(
                                      text: '\n',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text: 'Grilled chicken',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text:
                                          ' is a delectable culinary creation that tantalises the taste buds with its irresistible combination of smoky, savoury flavours and tender, juicy texture. This popular dish begins with succulent ',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text: 'chicken',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text:
                                          ' pieces, marinated in a flavourful blend of herbs, spices, and perhaps a hint of citrus for a delightful zing. \n',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text: 'The magic',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text: ' happens on the ',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text: 'grill',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text: ', where the ',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text: 'chicken',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                    TextSpan(
                                      text:
                                          ' is expertly cooked to perfection over an open flame or hot coals. The result is a symphony of aromas as the marinade caramelises and infuses the meat with a mouthwatering smokiness. The exterior boasts a tantalising char, offering a satisfying crunch that gives way to the juicy, well-cooked interior.',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                        letterSpacing: 0.50,
                                      ),
                                    ),
                                  ],
                                ),
                                textAlign: TextAlign.justify,
                              ),
                            ),
                          ),
                        ),
                      ),
                      // Content of Tab 2
                      Center(
                        child: Container(
                          width: width / 1.1,
                          height: 428,
                          decoration: ShapeDecoration(
                            color: const Color(0xFFEFF1ED),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35),
                            ),
                            shadows: const [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                          child: ListView.builder(
                            itemCount: Ingredients.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 14),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Container(
                                          margin:
                                              const EdgeInsets.only(right: 10),
                                          child: const Icon(
                                            Icons.circle,
                                            size: 6,
                                          ),
                                        ),
                                        Text(
                                          Ingredients[index],
                                          style: const TextStyle(
                                            color: Colors.black,
                                            fontSize: 17,
                                            fontFamily: 'Roboto',
                                            fontWeight: FontWeight.w400,
                                          ),
                                        ),
                                      ],
                                    ),
                                    const Icon(
                                      Icons.edit,
                                      color: Colors.green,
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      // Content of Tab 3
                      Center(
                        child: Container(
                          width: width / 1.1,
                          height: 418,
                          decoration: ShapeDecoration(
                            color: const Color(0xFFEFF1ED),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35),
                            ),
                            shadows: const [
                              BoxShadow(
                                color: Color(0x3F000000),
                                blurRadius: 4,
                                offset: Offset(0, 4),
                                spreadRadius: 0,
                              )
                            ],
                          ),
                          child: ListView.builder(
                            itemCount: nutrientsTitle.length,
                            itemBuilder: (context, index) {
                              return Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 14),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Container(
                                      margin: const EdgeInsets.only(right: 10),
                                      child: const Icon(
                                        Icons.circle,
                                        size: 8,
                                      ),
                                    ),
                                    Text(
                                      '${nutrientsTitle[index]}: ',
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontSize: 16,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                    Text(
                                      nutrientsText[index],
                                      style: const TextStyle(
                                        color: Colors.black,
                                        fontSize: 15,
                                        fontFamily: 'Roboto',
                                        fontWeight: FontWeight.w400,
                                      ),
                                    )
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 30, right: 30, bottom: 90),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 140,
                        height: 56,
                        decoration: ShapeDecoration(
                          color: const Color(0x7F40B518),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: TextButton(
                          onPressed: () {
                            Toast.show("The meal was added to your diet meals",
                                duration: 2,
                                gravity: Toast.bottom,
                                backgroundRadius: 12);

                            Future.delayed(const Duration(seconds: 2), () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => BottomNav(
                                    currentIndex: 0,
                                  ),
                                ),
                              );
                            });
                          },
                          child: const Text(
                            'Add to my meals',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontFamily: 'Roboto',
                              fontWeight: FontWeight.w400,
                              letterSpacing: 1.20,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        width: 140,
                        height: 56,
                        decoration: ShapeDecoration(
                          color: const Color(0x7F40B518),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: TextButton(
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => BottomNav(
                                    currentIndex: 3,
                                  ),
                                ));
                          },
                          child: const Text(
                            'Help',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                              fontFamily: 'Roboto',
                              fontWeight: FontWeight.w400,
                              letterSpacing: 1.20,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            bottom: 0,
            right: 0,
            left: 0,
            child: Container(
              alignment: Alignment.center,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(35),
                color: const Color.fromRGBO(18, 51, 33, 1),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  for (int index = 0; index < 4; index++)
                    Column(
                      children: [
                        InkWell(
                          onTap: () {
                            setState(() {
                              selectedIndex = index;
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        BottomNav(currentIndex: selectedIndex),
                                  ));
                            });
                          },
                          child: SvgPicture.asset(bottomIcons[index]),
                        ),
                        if (index == selectedIndex)
                          Container(
                            margin: const EdgeInsets.only(top: 4),
                            height: 7,
                            width: 39,
                            color: const Color(0xFF40B518),
                          ),
                      ],
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
