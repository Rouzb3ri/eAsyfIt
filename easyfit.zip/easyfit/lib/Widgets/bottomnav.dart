import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Screens/chatbotPage.dart';
import 'package:foodapp/Screens/homeScreen.dart';
import 'package:foodapp/Screens/mealAnalysisPage.dart';
import 'package:foodapp/Screens/progressPage.dart';

class BottomNav extends StatefulWidget {
  BottomNav({Key? key, required this.currentIndex}) : super(key: key);

  int currentIndex;

  @override
  State<BottomNav> createState() => _BottomNavState();
}

class _BottomNavState extends State<BottomNav> {
  //
  void onTap(int index) {
    setState(() {
      widget.currentIndex = index;
    });
  }

  List<Widget> pages = const [
    HomeScreen(),
    ProgressPage(),
    MealAnalysisPage(),
    ChatBotPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Other Screens
          IndexedStack(
            index: widget.currentIndex,
            children: pages,
          ),

          // BottomNav
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(35),
                color: const Color.fromRGBO(18, 51, 33, 1),
              ),
              child: BottomNavigationBar(
                type: BottomNavigationBarType.fixed,
                backgroundColor: Colors.transparent,
                showSelectedLabels: false,
                showUnselectedLabels: false,
                elevation: 0,
                onTap: onTap,
                currentIndex: widget.currentIndex,
                items: [
                  BottomNavigationBarItem(
                    label: 'Home',
                    icon: buildIcon(0, 'assets/homeIcon.svg'),
                  ),
                  BottomNavigationBarItem(
                    label: 'Process',
                    icon: buildIcon(1, 'assets/searchIcon.svg'),
                  ),
                  BottomNavigationBarItem(
                    label: 'Diet',
                    icon: buildIcon(2, 'assets/dietIcon.svg'),
                  ),
                  BottomNavigationBarItem(
                    label: 'Chatbot',
                    icon: buildIcon(3, 'assets/botIcon.svg'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildIcon(int index, String iconPath) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SvgPicture.asset(
            iconPath,
          ),
          if (widget.currentIndex == index)
            Container(
              margin: const EdgeInsets.only(top: 4),
              height: 7,
              width: 39,
              color: const Color(0xFF40B518),
            ),
        ],
      ),
    );
  }
}
