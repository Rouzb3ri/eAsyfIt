import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:foodapp/Widgets/bottomnav.dart';

class AppBarWidget extends StatelessWidget {
  bool isBack;

  AppBarWidget({Key? key, this.isBack = false}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, right: 20, left: 20),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(
                onTap: () {
                  if (isBack) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BottomNav(currentIndex: 2),
                        ));
                  }
                },
                child: SvgPicture.asset(
                  'assets/profile.svg',
                ),
              ),
              Container(
                margin: const EdgeInsets.only(top: 32),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'March 26 2024',
                      style: TextStyle(
                        color: Color(0xFF123321),
                        fontSize: 13,
                        fontFamily: 'Roboto',
                        fontWeight: FontWeight.w400,
                        height: 0,
                        letterSpacing: 2.60,
                      ),
                    ),
                    Icon(
                      Icons.arrow_drop_down_sharp,
                      size: 26,
                    )
                  ],
                ),
              ),
              Container(
                // width: 45,
                // height: 45,
                decoration: BoxDecoration(
                    color: const Color.fromRGBO(65, 181, 24, 1),
                    borderRadius: BorderRadius.circular(50)),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: SvgPicture.asset(
                    'assets/calenderIcon.svg',
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
