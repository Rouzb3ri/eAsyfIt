import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';

Widget LinerProccess(
    String title,
    String text,
    double percent,
    String percentText,
    String unit,
    double titleSize,
    double unitTextSize,
    double TotalTextSize,
    FontWeight totalTextW,
    double percentSize,
    Color linerColor,
    Color linerBgColor,
    double linerSpace) {
  return (Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Text.rich(
          TextSpan(
            children: [
              TextSpan(
                text: '${title} ',
                style: TextStyle(
                  color: const Color(0xFF123321),
                  fontSize: titleSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w800,
                ),
              ),
              TextSpan(
                text: unit,
                style: TextStyle(
                  color: const Color(0xFF123321),
                  fontSize: unitTextSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w300,
                ),
              ),
            ],
          ),
          textAlign: TextAlign.center,
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Container(
          width: 130,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                text,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: const Color(0xFF123321),
                  fontSize: TotalTextSize,
                  fontFamily: 'Roboto',
                  fontWeight: totalTextW,
                ),
              ),
              // SizedBox(
              //   width: 70,
              // ),
              Text(
                '$percentText',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: percentSize,
                  fontFamily: 'Roboto',
                  fontWeight: FontWeight.w400,
                ),
              ),
            ],
          ),
        ),
      ),
      SizedBox(
        height: linerSpace,
      ),
      new LinearPercentIndicator(
          width: 150.0,
          lineHeight: 6.0,
          percent: percent,
          barRadius: Radius.circular(10),
          progressColor: linerColor,
          backgroundColor: linerBgColor)
    ],
  ));
}
